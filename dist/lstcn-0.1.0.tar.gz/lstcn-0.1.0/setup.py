from setuptools import setup

setup(
    name='lstcn',
    version='0.1.0',
    description='Long short-term cognitive network',
    url='https://github.com/shuds13/pyexample',
    author='Gonzalo Napoles',
    author_email='g.r.napoles@uvt.nl',
    license='Apache License 2.0',
    packages=['lstcn'],
    install_requires=['hampel',
                      'numpy', 'scipy', 'scikit-learn', 'pandas',
                      ],

    classifiers=[
        'Development Status :: 1 - Planning',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: Apache Software License',
        'Operating System :: Microsoft :: Windows',
        'Operating System :: MacOS',
        'Programming Language :: Python :: 3.8',
    ],
)